# Python Script: 3DSMaxSceneParser.py
# Author: Andrew Smith
# Description: This python script will parse the output of a 3D Studio max scene which has been
#                               exported to ASCII Scene Exporter format so that it can be read in by a C/C++ program


#####################################################################################
# Class Name: parserdatastore                                                       #
# Class Description: This class stores and processes data for quad geometric shapes #
#                    as well as node names contained within a .ASE file             #
#####################################################################################
class parserdatastore:
        # Define the class constructor which just initialises the lists to be used
        def __init__(self):
                # Stores vertex values (may need to consider including vertex values from other shape primitives)
                self.vertexvalues = []
                # Stores all node names that exist in the file
                self.nodenames = []
                # Stores the file contents
                self.filecontents = ""
                
        # A method to output the number of node names in a list
        def get_number_of_nodenames(self):
                return len(self.nodenames)

        # A method which will be used to add a node name to a list of node names (general list)
        def add_node_name(self, node_name_in):
                self.nodenames.append(node_name_in)
               
        # A method that will check if a node name already exists in the list
        def node_name_exists(self, node_name_in):
                startcounter = 0

                # Get the current length of the list
                stopcounter = len(self.nodenames)
                endcondition = False
                node_name_found = False
                
                # The while loop executes only if the list has at least 1 element in it
                if stopcounter > 0:
                        # This while loop searches through the list of node names to see if the node
                        # name passed in already exists within the list
                        while (endcondition == False):
                                # Check if the node name passed in has been found
                                if self.nodenames[startcounter] == node_name_in:
                                        node_name_found = True
                                        endcondition = True
                                
                                # Check if the end element of the list has been reached
                                if startcounter == stopcounter-1:
                                        endcondition = True

                                # Increment the index counter for the list of node names
                                startcounter = startcounter + 1
                        
                # Return the result regardless
                return node_name_found
                
        # A function that outputs all node names in the list
        def output_all_node_names(self):
                #print "In output_all_node_names"
                print self.nodenames[0]
                for node_name in self.nodenames:
                        print node_name

        # A method that outputs all box node names in the box node names list
        def output_box_node_names(self):
                #print "In output_box_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("box_")] == "box_":
                                print node_name
                print

        # A method that outputs all sphere node names
        def output_sphere_node_names(self):
                #print "In output_sphere_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("sphere_")] == "sphere_":
                                print node_name
                print
                        

        # A method that outputs all cylinder node names
        def output_cylinder_node_names(self):
                #print "In output_cylinder_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("cylinder_")] == "cylinder_":
                                print node_name
                print

        # A method that outputs all torus node names
        def output_torus_node_names(self):
                #print "In output_torus_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("torus_")] == "torus_":
                                print node_name
                print

        # A method that outputs all cone node names
        def output_cone_node_names(self):
                #print "In output_cone_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("cone_")] == "cone_":
                                print node_name
                print

        # A method that outputs all geosphere node names
        def output_geosphere_node_names(self):
                #print "In output_geosphere_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("geosphere_")] == "geosphere_":
                                print node_name
                print

        # A method that outputs all tube node names
        def output_tube_node_names(self):
                #print "In output_tube_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("tube_")] == "tube_":
                                print node_name
                print

        # A method that outputs all pyramid node names
        def output_pyramid_node_names(self):
                #print "In output_pyramid_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("pyramid_")] == "pyramid_":
                                print node_name
                print

        # A method that outputs all plane node names
        def output_plane_node_names(self):
                #print "In output_plane_node_names"
                print
                for node_name in self.nodenames:
                        if node_name[0:len("plane_")] == "plane_":
                                print node_name
                print

        # A method that will output all node lists
        def output_all_node_lists(self):
                # Output box node names 
                print "---------------------------------------------------------"
                print "Box node names include the following: "
                self.output_box_node_names()
                print "---------------------------------------------------------"
                print

                # Output sphere node names
                print "---------------------------------------------------------"
                print "Sphere node names include the following: "
                self.output_sphere_node_names()
                print "---------------------------------------------------------"
                print

                # Output cylinder
                print "---------------------------------------------------------"
                print "Cylinder node names include the following: "
                self.output_cylinder_node_names()
                print "---------------------------------------------------------"
                print

                # Torus
                print "---------------------------------------------------------"
                print "Torus node names include the following: "
                self.output_torus_node_names()
                print "---------------------------------------------------------"
                print

                # Cone
                print "---------------------------------------------------------"
                print "Cone node names include the following: "
                self.output_cone_node_names()
                print "---------------------------------------------------------"
                print

                # Geosphere
                print "---------------------------------------------------------"
                print "Geosphere node name include the following: "
                self.output_geosphere_node_names()
                print "---------------------------------------------------------"
                print

                # Tube
                print "---------------------------------------------------------"
                print "Tube node names include the following: "
                self.output_tube_node_names()
                print "---------------------------------------------------------"
                print

                # Pyramid
                print "---------------------------------------------------------"
                print "Pyramid node names include the following: "
                self.output_pyramid_node_names()
                print "---------------------------------------------------------"
                print

                # Plane
                print "---------------------------------------------------------"
                print "Plane node names include the following: "
                self.output_plane_node_names()
                print "---------------------------------------------------------"
                print 
        
        # A function that retrieves a node_name from the list based on element number
        def get_node_name(self, element_no_in):
                # Check to see if there are any elements to return
                return_value = -1 # -1 identifies that the intended element does not exist

                # Perform a check to if any elements are in the list
                total_elements = len(self.nodenames)

                # If there is at least one element in the list then retrieve passed in element
                # number from the list
                if total_elements > 0:
                        return_value = self.nodenames[element_no_in]
                
                # Return the outcome
                return return_value

        # Define a method that returns the number of node names stored
        def get_number_of_node_names(self):
                return (len(self.nodenames) - 1)
                
        # A method which will be used to add the vertex values to the vertex store
        def add_vertex_values(self, vertexvaluesin):
                self.vertexvalues.append(vertexvaluesin)

        # A method to get the node element number
        #def get_node_element_no(self):
                

               
#####################################################################################

# Declare an instance of class quadvertexstore
data_bank = parserdatastore()

#####################################################################################
# Class Name: configcontrol                                                         #
# Description: This class is used to handle the configuration file (xml)            #
#####################################################################################
class configcontrol:
        # Define the class constructor
        def __init__(self):
                self.start_position = 0.0
                self.file_output_folder = ""
                self.file_to_parse = ""
                self.debug_mode = "ON"
                self.parse_materials = "OFF"
                self.parse_lighting = "OFF"
                self.parse_textures = "OFF"
                self.xml_file_contents = ""
                self.xml_file = "config.xml"
        
        # Define a method that will set the start position (camera setting)
        def set_start_position(self, start_pos_in):
                self.start_position = start_pos_in
                
        # Define a method that will set the file output folder
        def set_file_output_folder(self, file_output_folder_in):
                self.file_output_folder = file_output_folder_in
                
        # Define a method that will set the file to parse
        def set_file_to_parse(self, file_to_parse_in):
                self.file_to_parse = file_to_parse_in
                
        # Define a method that will set the debug mode
        def set_debug_mode(self, debugmodein):
                self.debug_mode = debugmodein
                
        # Define a method that will set whether to parse materials
        def set_parse_materials(self, materialsmodein):
                self.parse_materials = materialsmodein
                
        # Define a method that will set whether to parse lighting
        def set_parse_lighting(self, lightingmodein):
                self.parse_lighting = lightingmodein
                
        # Define a method that will set whether to parse textures
        def set_parse_textures(self, texturemodein):
                self.parse_textures = texturemodein
                
        # A method for displaying all set values
        def print_settings(self):
                print "Start Position: " + self.start_position
                print "Output Folder: " + self.file_output_folder
                print "File to Parse: " + self.file_to_parse
                print "Debug Mode: " + self.debug_mode
                print "Parse Materials: " + self.parse_materials
                print "Parse Lighting: " + self.parse_lighting
                print "Parse Textures: " + self.parse_textures

        # Define a method that will return the value of the start position
        def return_start_position(self):
                return self.start_position

        # Define a method that will return the value of the output folder
        def return_output_folder(self):
                return self.file_output_folder

        # Define a method that will return the file to parse
        def return_file_to_parse(self):
                return self.file_to_parse

        # Define a method that will return the debug mode
        def return_debug_mode(self):
                return self.debug_mode

        # Define a method that will return material parsing
        def return_materials(self):
                return self.parse_materials

        # Define a method that will return light parsing
        def return_lighting(self):
                return self.parse_lighting

        # Define a method that will return textures parsing
        def return_textures(self):
                return self.parse_textures

        # Define a method that loads the xml configuration file
        # into memory
        def load_config_file_into_memory(self):
                file_pointer = open(self.xml_file, 'r')

                # Copy contents of file into memory
                self.xml_file_contents = file_pointer.read()

                #print "load_config_file_into_memory completed......"

        # Define a function that loads data from a given tag
        def load_data_from_tag(self, targettagnamein):
                # Variable declaration
                endcondition = False
        
                targettagname = targettagnamein
        
                indexcounter1 = 0
                indexcounter2 = len(targettagname) # Length of the target tagname
                tempword = ""
        
                # Search for the target tag name
                while (endcondition == False):
                        # Get the length of target tag name characters from file stream
                        tempword = self.xml_file_contents[indexcounter1:indexcounter2]
                
                        # Compare the tempword with the target tag name
                        if tempword == targettagname:
                                endcondition = True
                        
                        if tempword != targettagname:
                                indexcounter1 = indexcounter1 + 1
                                indexcounter2 = indexcounter2 + 1
                                tempword = ""
                        
                
                # Reset variables to prepare for the loop to retrieve the data
                endcondition = False
                datalength = 0
                indexcounter3 = indexcounter2
        
                while(endcondition == False):
                        if self.xml_file_contents[indexcounter3+1] == '<':
                                endcondition = True
                        
                        indexcounter3 = indexcounter3 + 1
                        datalength = datalength + 1
                
                # Assign depending on the target tag name
        
                # Store camera settings (start position)
                if targettagname == "<camerasettings>":
                        self.set_start_position(self.xml_file_contents[indexcounter2:indexcounter2+datalength])
                
                # Store output folder name
                if targettagname == "<outputfolder>":
                        self.set_file_output_folder(self.xml_file_contents[indexcounter2:indexcounter2+datalength])
                
                # Store the file to parse
                if targettagname == "<filetoparse>":
                        self.set_file_to_parse(self.xml_file_contents[indexcounter2:indexcounter2+datalength])
                
                # Store the debug mode
                if targettagname == "<debugmode>":
                        self.set_debug_mode(self.xml_file_contents[indexcounter2:indexcounter2+datalength])
                
                # Store whether to parse materials or not
                if targettagname == "<materials>":
                        self.set_parse_materials(self.xml_file_contents[indexcounter2:indexcounter2+datalength])
                
                # Store whether to store any information on lighting
                if targettagname == "<lighting>":
                        self.set_parse_lighting(self.xml_file_contents[indexcounter2:indexcounter2+datalength])
                
                # Store information on textures
                if targettagname == "<textures>":
                        self.set_parse_textures(self.xml_file_contents[indexcounter2:indexcounter2+datalength])                

        # Define a method that extracts the config details from memory
        # and stores them in a unique location
        def extract_config_file_details(self):
                # Debug output statement        
                #print "extract_config_file_details"
        
                # Load camera settings
                self.load_data_from_tag("<camerasettings>")

                # Load output folder
                self.load_data_from_tag("<outputfolder>")
        
                # Load file to parse
                self.load_data_from_tag("<filetoparse>")
        
                # Load debug mode select
                self.load_data_from_tag("<debugmode>")
        
                # Load materials select
                self.load_data_from_tag("<materials>")
        
                # Load lighting select
                self.load_data_from_tag("<lighting>")
        
                # Load textures select
                self.load_data_from_tag("<textures>")
               
###################################################################################

# Define an instance of class configcontrol
config_control_panel = configcontrol()

# Global variables to store config file values

# XML Configuration file name
xml_config_filename = "config.xml"

# Flag to identify a valid configuration file
validconfigfile_identified = "false"

# File contents
filecontents = ""

# A variable to store the current position of searching through node names
current_nodename_search_pos = 0


        

# This function is used to get all node names in the file and store them in a list
def extract_all_node_names():
        node_name_retrieved = ""
        endcondition = False
        name_exists = False
        elementcount = 1
        
        # This while loop will only terminate once end of the file stream is reached
        while (endcondition == False):
                # Get the next node name in the file
                node_name_retrieved = get_next_node_name()
                #print node_name_retrieved
                
                # Check if end of file stream is reached
                if node_name_retrieved == "nomorenodenames":
                        endcondition = True
                        
                # Check if the node name already exists in list
                name_exists = data_bank.node_name_exists(node_name_retrieved)
                #print name_exists
                
                # On the condition that the node name is not in the list only
                # then add it to the node name list
                if name_exists == False:
                        data_bank.add_node_name(node_name_retrieved)
                        elementcount = elementcount + 1
                        


# This function is used to get the next node name in the file
def get_next_node_name():
        global current_nodename_search_pos
        # print current_nodename_search_pos
        
        # Variable declaration
        endcondition = False
        tempword = ""
        targettagname = "NODE_NAME"
        node_name = "Nothing"
        end_of_file = False

        # Debug output statement
        #print "Node name: " + node_name
        
        # This index counter stores the last start position
        indexcounter1 = current_nodename_search_pos
        
        # This index counter stores the last end position stored
        indexcounter2 = (indexcounter1 + len(targettagname))
                        
        # Include file contents with an end marker
        all_filecontents = data_bank.filecontents + '#' # The hash will be used to detect end of file stream
        
        # Do a check to see if end of the file stream has been reached
        if all_filecontents[indexcounter1] == '#':
                end_of_file = True
                endcondition = True
                
        if all_filecontents[indexcounter1+1] == '#':
                end_of_file = True
                endcondition = True
        
        # This while loop searches for the targettagname in the file stream
        # The loop is ended when the tagname is found in the file stream
        while(endcondition == False):
                tempword = all_filecontents[indexcounter1:indexcounter2]
                
                # Comparison check
                if tempword == targettagname:
                        endcondition = True
                        
                if tempword != targettagname:
                        indexcounter1 = indexcounter1 + 1
                        indexcounter2 = indexcounter2 + 1
                        tempword = ""

                # Do a check to see if end of the file stream has been reached
                if all_filecontents[indexcounter1] == '#':
                        end_of_file = True
                        endcondition = True
                
                if all_filecontents[indexcounter1+1] == '#':
                        end_of_file = True
                        endcondition = True
                        
        
        # Set variables back to get values
        if end_of_file == False:
                endcondition = False
        datalength = 0
        # Move start position to first character of 
        indexcounter2 = indexcounter2 + 2
        indexcounter3 = indexcounter2
        
        # This while loop collects the node name
        while(endcondition == False):
                if fcontents[indexcounter3+1] == '"':
                        endcondition = True
                        
                indexcounter3 = indexcounter3 + 1
                datalength = datalength + 1
                
        # Grab node name if the end of the file is not reached
        if end_of_file == False:
                node_name = fcontents[indexcounter2:indexcounter2+datalength]

        # Assign node name as nomorenodenames if end of the file has been reached
        if end_of_file == True:
                node_name = "nomorenodenames"
        
        # Debug output statement
        # print "Node name: " + node_name
        
        # Record the end position so the following node name can be found
        # Error checking needs adding here incase no node name is found in the file
        current_nodename_search_pos = (indexcounter2+datalength)
        
        return node_name

        # Store in node_name store above in class but check to see if it is already there
        
# This function is used to get the node type from the node name passed in
# such as box_gameroom_etc...
def get_nodetype_from_nodename(nodenamein):
        endcondition = False
        indexcounter1 = 0
        node_type = ""
        
        # A while loop to search until the underscore is found to get the node type
        while(endcondition == False):
                if nodenamein[indexcounter1+1] == '_':
                        endcondition = True
                        
                indexcounter1 = indexcounter1 + 1
                
        node_type = nodenamein[0:indexcounter1]
        
        return node_type
        
# A function to get the end of a node names position in the
# file stream
def get_location_after_nodename(node_name_in):
        endcondition = False
        indexcounter1 = 0
        indexcounter2 = len(node_name_in)

        # Grab the file contents from the class parserdatastore
        fcontents = data_bank.filecontents

        while(endcondition == False):
                node_name = fcontents[indexcounter1:indexcounter2]
                #print node_name

                # Check if the node name matches the node name
                # passed in
                if node_name == node_name_in:
                        endcondition = True

                if node_name != node_name_in:
                        indexcounter1 = indexcounter1 + 1
                        indexcounter2 = indexcounter2 + 1

        # Return the end position
        return indexcounter2

# A function that reads in all vertex data from the file
def extract_all_vertex_data():
        endcondition = False
        tempdata = ""
        node_count = 0
        
        # Get how many nodes there are to get vertex values for
        number_of_nodes = data_bank.get_number_of_nodenames()

        # Loop while end condition has been met
        # The loop ends when all vertex values have been read in
        while(endcondition == False):
                # Find start of vertex data
                

                # Find end of vertex data


                # tempdata = filecontents[startcount:endcount]

                

                

# Set an end condition for the config verify loop
endcondition = False

# Load the XML Configuration file into memory
config_control_panel.load_config_file_into_memory()

# Extract the data from memory and store
config_control_panel.extract_config_file_details()

# Debug output assigned values
config_control_panel.print_settings()

# A user will not be allowed to continue until they confirm the details
# in the xml configuration file are correct or incorrect
while (endcondition == False):
        print "\n\nThese are the settings that have been detected in " + xml_config_filename
        print "Are these details correct? (y/n)"

        # Collect the user's input
        user_response = raw_input()

        # End condition is only True if user response is one of the following
        if user_response == 'y' or user_response == 'Y':
                endcondition = True

        if user_response == 'n' or user_response == 'N':
                endcondition = True

# Continue as normal if the user confirmed the details are correct
if user_response == 'y' or user_response == 'Y':
        # If details are correct then load in the file contents from ASE file
        # Open the file to parse
        filepointer = open(config_control_panel.file_to_parse, 'r')
        
        # Get the data from the file and put into the class
        data_bank.filecontents = filepointer.read()

        # Extract all node names
        extract_all_node_names()

        # Retrieve a number of node names that are stored
        iNo_of_NodeNames = data_bank.get_number_of_node_names()

        # Output the total number of nodes retrieved from the ASE file
        print "Number of node names: " + str(iNo_of_NodeNames)

        # Output all node lists
        data_bank.output_all_node_lists()

        #read_data_in_for_node(0)

        

# Do not continue if the details that are in the configuration file are incorrect
if user_response == 'n' or user_response == 'N':
        print "Please check the settings in " + xml_config_filename + " before continuing"
        print "Press any key to end...."
        u = raw_input()







