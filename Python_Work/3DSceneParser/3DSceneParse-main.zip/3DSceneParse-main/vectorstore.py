# This script has a class that will store vertices

class vertexstore:
        # Constructor
        def __init__(self):
                self.vertexvalues = []

        # This method is used to add vertex values to the array list
        def add_vertex_values(self, vertexvaluesin):
                self.vertexvalues.append(vertexvaluesin)
                
        # This function outputs vertex values to file
        def output_to_file(filenameandlocationin):
                print "Output file"
                
        # This function outputs all vertex values to the screen stdout
        def showallvertexvalues(self):
                indexcounter = 0
                limit = len(self.vertexvalues)
                print "Showing all vertex values"
                while(indexcounter != limit):
                        print self.vertexvalues[indexcounter]
                        indexcounter = indexcounter + 1
                
                
# Lets create an instance of the class and use it to our means
quad_store = vertexstore()

quad_store.add_vertex_values("1.0,2.0,3.0")
quad_store.add_vertex_values("0.5,2.0,3.0")
quad_store.add_vertex_values("1.5,2.0,3.5")
quad_store.showallvertexvalues()
print "press any key to end.."
a = raw_input()
                
