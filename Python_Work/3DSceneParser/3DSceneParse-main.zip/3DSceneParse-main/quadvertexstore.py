#####################################################################################
# Class Name: parserdatastore                                                       #
# Class Description: This class stores and processes data for quad geometric shapes #
#                    as well as node names contained within a .ASE file             #
#####################################################################################
class parserdatastore:
        # Define the class constructor which just initialises the lists to be used
        def __init__(self):
                self.vertexvalues = []
                self.nodenames = []
                
        # A method which will be used to add a node name to a list of node names
        def add_node_name(self, node_name_in):
                self.nodenames.append(node_name_in)     
                
        # A method that will check if a node name already exists in the list
        def node_name_exists(self, node_name_in):
                startcounter = 0

                # Get the current length of the list
                stopcounter = len(self.nodenames)
                endcondition = False
                node_name_found = False
                
                # The while loop executes only if the list has at least 1 element in it
                if stopcounter > 0:
                        # This while loop searches through the list of node names to see if the node
                        # name passed in already exists within the list
                        while (endcondition == False):
                                # Check if the node name passed in has been found
                                if self.nodenames[startcounter] == node_name_in:
                                        node_name_found = True
                                        endcondition = True
                                
                                # Check if the end element of the list has been reached
                                if startcounter == stopcounter-1:
                                        endcondition = True

                                # Increment the index counter for the list of node names
                                startcounter = startcounter + 1
                        
                # Return the result regardless
                return node_name_found
                
        # A function that outputs all node names in the list
        def output_all_node_names(self):
            for node_name in self.nodenames:
                print node_name
        
        # A function that retrieves a node_name from the list based on element number
        def get_node_name(self, element_no_in):
                # Check to see if there are any elements to return
                return_value = -1 # -1 identifies that the intended element does not exist

                # Perform a check to if any elements are in the list
                total_elements = len(self.nodenames)

                # If there is at least one element in the list then retrieve passed in element
                # number from the list
                if total_elements > 0:
                        return_value = self.nodenames[element_no_in]
                
                # Return the outcome
                return return_value
                
        # A method which will be used to add the vertex values to the vertex store
        def add_vertex_values(self, vertexvaluesin):
                self.vertexvalues.append(vertexvaluesin)
                
#####################################################################################

#################   BELOW IS CLASS TESTING SCRIPT  ######################


# Declare an instance of class quadvertexstore
data_bank = parserdatastore()

# Add some node names
data_bank.add_node_name("box_gameroom_01")
#data_bank.add_node_name("box_gameroom_02")
#data_bank.add_node_name("box_gameroom_03")

check = data_bank.node_name_exists("box_gameroom_03")

if check == True:
        print "Node name exists"

if check == False:
        print "Node name does not exist"

data_bank.output_all_node_names()
print data_bank.get_node_name(0)
a = raw_input()
