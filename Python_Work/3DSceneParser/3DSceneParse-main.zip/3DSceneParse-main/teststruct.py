myvertices = []

def addvalues(myvalues):
        global myvertices
        myvertices.append(myvalues)

# Add a string of vertex values
myvertices.append("1.0,2,0,3.0")
myvertices.append("1.5,2.6,3.8")

icounter = 0

addvalues("1.0, 3.0, 5.0")

i = len(myvertices)

while(icounter < i):
	print myvertices[icounter]
	icounter = icounter + 1



a = raw_input()
