def search_till_end_of_file():
        endcondition = False
        file_pointer = open("junkfile.txt", 'r')
        
        filecontents = file_pointer.read()

        lengthofdata = len(filecontents)

        allfilecontents = filecontents + '#'
        
        indexcounter = 0
        
        while(endcondition == False):
                if allfilecontents[indexcounter+1] == '#':
                        endcondition = True
                        
                indexcounter = indexcounter + 1

                #if indexcounter == lengthofdata-1:
                #        endcondition = True
                        
        print indexcounter

search_till_end_of_file()
