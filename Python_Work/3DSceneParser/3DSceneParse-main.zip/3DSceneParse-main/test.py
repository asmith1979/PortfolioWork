x = 0.0
y = 0.0
z = 0.0

# This function will take a line of vertex data including white spaces
# and then seperate values into x, y and z components
def extract_vertex_data(vertexdatain):
	# Local variable declaration
	global x
	global y
	global z
	
	tempvalue = ""
	
	endcondition = "false"
	
	indexcounter1 = 0
	
	# Get x value
	while(endcondition == "false"):
		if vertexdatain[indexcounter1] == ' ':
			endcondition = "true"
			
		indexcounter1 = indexcounter1 + 1
		
	tempvalue = vertexdatain[0:indexcounter1]
	
	x = tempvalue
	print "X value: " + x
	
	tempvalue = ""
	endcondition = "false"
	
	# A loop to go past the white space between the values to be retrieved
	indexcounter1 = indexcounter1 + 1
	while(endcondition == "false"):
		if vertexdatain[indexcounter1] != ' ':
			endcondition = "true"
			
		indexcounter1 = indexcounter1 + 1
			
	# A loop to get the y value
	endcondition = "false"
	indexcounter2 = indexcounter1
	while(endcondition == "false"):
		if vertexdatain[indexcounter2] == ' ':
			endcondition = "true"
			
		indexcounter2 = indexcounter2 + 1
		
	tempvalue = vertexdatain[indexcounter1-1:indexcounter2]
	
	y = tempvalue
	print "Y value: " + y
	
	# Reset variables to retrieve z value
	tempvalue = ""
	endcondition = "false"

	# A while loop to retrieve the z-value
	endcondition = "false"
	indexcounter3 = indexcounter2
	while(endcondition == "false"):
		if vertexdatain[indexcounter3] == '\n':
			endcondition = "true"
		
		indexcounter3 = indexcounter3 + 1
		
	tempvalue = vertexdatain[indexcounter2:indexcounter3]
	
	z = tempvalue
	print "Z value: " + z
	u = raw_input()
	
	
extract_vertex_data("0.3123  -5.8177 0.0000\n")